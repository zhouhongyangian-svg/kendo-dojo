import { useState } from "react";
import { Redirect } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";

const loginSchema = z.object({
  email: z.string().email("请输入有效的电子邮箱"),
  password: z.string().min(1, "请输入密码"),
});

type LoginFormValues = z.infer<typeof loginSchema>;

export default function Login() {
  const { member, login, isLoading } = useAuth();
  const { toast } = useToast();
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const form = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  if (isLoading) return null;

  if (member) {
    const dest = member.role === "admin"
      ? "/admin/announcements"
      : member.role === "course_admin"
      ? "/admin/courses"
      : "/announcements";
    return <Redirect to={dest} />;
  }

  const onSubmit = async (data: LoginFormValues) => {
    setIsLoggingIn(true);
    try {
      await login(data);
      toast({
        title: "登录成功",
        description: "欢迎回到长安剑士会",
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "登录失败",
        description: error?.message || "账号或密码错误",
      });
    } finally {
      setIsLoggingIn(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center items-center relative overflow-hidden">
      <div className="absolute inset-0 opacity-20 pointer-events-none">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(220,38,38,0.1)_0,transparent_100%)]"></div>
      </div>
      
      <div className="w-full max-w-md p-8 bg-card border border-border shadow-2xl relative z-10">
        <div className="text-center mb-10">
          <h1 className="text-3xl font-bold tracking-widest text-primary mb-2">长安剑士会</h1>
          <p className="text-sm text-muted-foreground tracking-widest">系统登录</p>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-muted-foreground tracking-wider">电子邮箱</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="admin@dojo.com" 
                      {...field} 
                      className="bg-background border-border focus-visible:ring-primary rounded-none"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-muted-foreground tracking-wider">密码</FormLabel>
                  <FormControl>
                    <Input 
                      type="password" 
                      placeholder="••••••••" 
                      {...field} 
                      className="bg-background border-border focus-visible:ring-primary rounded-none"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button 
              type="submit" 
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground rounded-none tracking-widest mt-8" 
              disabled={isLoggingIn}
            >
              {isLoggingIn ? "登 录 中..." : "登 录"}
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
}
