import { useState } from "react";
import { useListAnnouncements, getListAnnouncementsQueryKey, useCreateAnnouncement, useDeleteAnnouncement, useUpdateAnnouncement } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";

const announcementSchema = z.object({
  title: z.string().min(1, "请输入标题"),
  content: z.string().min(1, "请输入内容"),
  isPinned: z.boolean().default(false),
});

type AnnouncementFormValues = z.infer<typeof announcementSchema>;

export default function AdminAnnouncements() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: announcements, isLoading } = useListAnnouncements({ query: { queryKey: getListAnnouncementsQueryKey() } });
  const [isOpen, setIsOpen] = useState(false);

  const createAnnouncement = useCreateAnnouncement({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAnnouncementsQueryKey() });
        toast({ title: "发布成功", description: "公告已发布" });
        setIsOpen(false);
        form.reset();
      }
    }
  });

  const updateAnnouncement = useUpdateAnnouncement({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAnnouncementsQueryKey() });
        toast({ title: "更新成功" });
      }
    }
  });

  const deleteAnnouncement = useDeleteAnnouncement({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListAnnouncementsQueryKey() });
        toast({ title: "删除成功", description: "公告已移除" });
      }
    }
  });

  const form = useForm<AnnouncementFormValues>({
    resolver: zodResolver(announcementSchema),
    defaultValues: {
      title: "",
      content: "",
      isPinned: false
    },
  });

  const onSubmit = (data: AnnouncementFormValues) => {
    createAnnouncement.mutate({ data });
  };

  const togglePin = (id: number, isPinned: boolean) => {
    updateAnnouncement.mutate({ id, data: { isPinned } });
  };

  if (isLoading) return <div>加载中...</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center border-b border-border pb-4">
        <h1 className="text-2xl font-bold tracking-widest text-primary border-l-4 border-primary pl-4">公告管理</h1>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90 rounded-none tracking-widest">发布公告</Button>
          </DialogTrigger>
          <DialogContent className="bg-card border-border rounded-none sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle className="tracking-widest">新公告</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>标题</FormLabel>
                      <FormControl>
                        <Input placeholder="输入标题" {...field} className="rounded-none border-border bg-background" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>内容</FormLabel>
                      <FormControl>
                        <Textarea rows={6} placeholder="输入正文" {...field} className="rounded-none border-border bg-background" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="isPinned"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-none border border-border bg-background p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">置顶公告</FormLabel>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
                <div className="pt-4">
                  <Button type="submit" disabled={createAnnouncement.isPending} className="w-full bg-primary hover:bg-primary/90 rounded-none tracking-widest">
                    确认发布
                  </Button>
                </div>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-4">
        {announcements?.map(a => (
          <div key={a.id} className={`p-4 border bg-card ${a.isPinned ? 'border-secondary' : 'border-border'}`}>
            <div className="flex justify-between items-start mb-2">
              <div className="flex items-center gap-3">
                <h3 className="font-bold text-lg">{a.title}</h3>
                {a.isPinned && <span className="bg-secondary text-secondary-foreground text-xs px-2 py-0.5 rounded-sm">置顶</span>}
              </div>
              <div className="flex items-center gap-4">
                <span className="text-sm text-muted-foreground">{format(new Date(a.createdAt), "yyyy-MM-dd")}</span>
                <div className="flex items-center gap-2">
                  <Switch 
                    checked={a.isPinned} 
                    onCheckedChange={(c) => togglePin(a.id, c)}
                    disabled={updateAnnouncement.isPending}
                  />
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="text-destructive hover:text-destructive hover:bg-destructive/10 h-8 px-2 rounded-none"
                    onClick={() => {
                      if(confirm('确定删除此公告？')) deleteAnnouncement.mutate({ id: a.id });
                    }}
                  >
                    删除
                  </Button>
                </div>
              </div>
            </div>
            <p className="text-muted-foreground whitespace-pre-wrap">{a.content}</p>
          </div>
        ))}
        {(!announcements || announcements.length === 0) && (
          <div className="text-center py-12 text-muted-foreground border border-border">
            暂无公告记录
          </div>
        )}
      </div>
    </div>
  );
}
