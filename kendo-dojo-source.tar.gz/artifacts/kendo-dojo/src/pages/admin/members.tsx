import { useState } from "react";
import { useListMembers, getListMembersQueryKey, useCreateMember, useDeleteMember, useUpdateMemberStatus } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Shield, Users } from "lucide-react";

const ROLE_LABEL: Record<string, string> = {
  admin: "超级管理员",
  course_admin: "课程管理员",
  member: "会员",
};

const ROLE_BADGE: Record<string, string> = {
  admin: "bg-primary/20 text-primary border border-primary/30",
  course_admin: "bg-blue-900/40 text-blue-300 border border-blue-700/40",
  member: "bg-muted text-muted-foreground border border-border",
};

const baseMemberSchema = z.object({
  name: z.string().min(1, "请输入姓名"),
  email: z.string().email("请输入有效的电子邮箱"),
  password: z.string().min(6, "密码至少6位"),
  phone: z.string().optional(),
});

const adminSchema = baseMemberSchema.extend({
  role: z.enum(["admin", "course_admin"]),
});

type MemberFormValues = z.infer<typeof baseMemberSchema>;
type AdminFormValues = z.infer<typeof adminSchema>;

export default function AdminMembers() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const { data: members, isLoading } = useListMembers({ query: { queryKey: getListMembersQueryKey() } });
  const [memberDialogOpen, setMemberDialogOpen] = useState(false);
  const [adminDialogOpen, setAdminDialogOpen] = useState(false);

  const createMember = useCreateMember({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
        toast({ title: "添加成功", description: "新会员已加入" });
        setMemberDialogOpen(false);
        memberForm.reset();
      },
      onError: (err: any) => {
        toast({ variant: "destructive", title: "添加失败", description: err?.response?.data?.error || "无法添加" });
      },
    },
  });

  const deleteMember = useDeleteMember({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
        toast({ title: "删除成功", description: "账户已移除" });
      },
    },
  });

  const updateStatus = useUpdateMemberStatus({
    mutation: {
      onSuccess: (data) => {
        queryClient.invalidateQueries({ queryKey: getListMembersQueryKey() });
        toast({ title: "状态已更新", description: `${data.name} 已${data.status === "active" ? "启用" : "停用"}` });
      },
      onError: () => {
        toast({ variant: "destructive", title: "更新失败", description: "无法修改状态" });
      },
    },
  });

  const memberForm = useForm<MemberFormValues>({
    resolver: zodResolver(baseMemberSchema),
    defaultValues: { name: "", email: "", password: "", phone: "" },
  });

  const adminForm = useForm<AdminFormValues>({
    resolver: zodResolver(adminSchema),
    defaultValues: { name: "", email: "", password: "", phone: "", role: "course_admin" },
  });

  const onMemberSubmit = (data: MemberFormValues) => {
    createMember.mutate({ data: { ...data, role: "member" } });
  };

  const onAdminSubmit = (data: AdminFormValues) => {
    createMember.mutate({ data });
  };

  if (isLoading) return <div className="text-muted-foreground p-8">加载中...</div>;

  const admins = members?.filter((m) => m.role !== "member") ?? [];
  const regularMembers = members?.filter((m) => m.role === "member") ?? [];

  const MemberFormFields = ({ form, isPending, onClose }: { form: any; isPending: boolean; onClose: () => void }) => (
    <>
      <FormField control={form.control} name="name" render={({ field }) => (
        <FormItem>
          <FormLabel>姓名</FormLabel>
          <FormControl><Input placeholder="输入姓名" {...field} className="rounded-none border-border bg-background" /></FormControl>
          <FormMessage />
        </FormItem>
      )} />
      <FormField control={form.control} name="email" render={({ field }) => (
        <FormItem>
          <FormLabel>邮箱</FormLabel>
          <FormControl><Input placeholder="输入邮箱" {...field} className="rounded-none border-border bg-background" /></FormControl>
          <FormMessage />
        </FormItem>
      )} />
      <FormField control={form.control} name="password" render={({ field }) => (
        <FormItem>
          <FormLabel>密码</FormLabel>
          <FormControl><Input type="password" placeholder="设置密码（最少6位）" {...field} className="rounded-none border-border bg-background" /></FormControl>
          <FormMessage />
        </FormItem>
      )} />
      <FormField control={form.control} name="phone" render={({ field }) => (
        <FormItem>
          <FormLabel>电话（可选）</FormLabel>
          <FormControl><Input placeholder="输入电话" {...field} className="rounded-none border-border bg-background" /></FormControl>
          <FormMessage />
        </FormItem>
      )} />
      <div className="pt-4 flex gap-2">
        <Button type="button" variant="outline" className="flex-1 rounded-none border-border" onClick={onClose}>取消</Button>
        <Button type="submit" disabled={isPending} className="flex-1 bg-primary hover:bg-primary/90 rounded-none tracking-widest">
          {isPending ? "提交中..." : "确认添加"}
        </Button>
      </div>
    </>
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center border-b border-border pb-4">
        <h1 className="text-2xl font-bold tracking-widest text-primary border-l-4 border-primary pl-4">会员管理</h1>
        <div className="flex gap-2">
          <Button
            variant="outline"
            className="rounded-none border-primary/50 text-primary hover:bg-primary/10 tracking-widest gap-2"
            onClick={() => setAdminDialogOpen(true)}
          >
            <Shield className="w-4 h-4" />
            添加管理员
          </Button>
          <Button
            className="bg-primary hover:bg-primary/90 rounded-none tracking-widest gap-2"
            onClick={() => setMemberDialogOpen(true)}
          >
            <Users className="w-4 h-4" />
            添加会员
          </Button>
        </div>
      </div>

      {/* Admin section */}
      {admins.length > 0 && (
        <div>
          <h2 className="text-sm font-bold mb-3 tracking-widest text-muted-foreground flex items-center gap-2">
            <Shield className="w-3.5 h-3.5 text-primary" />
            管理员账户
          </h2>
          <div className="border border-border bg-card overflow-hidden mb-6">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="text-muted-foreground">姓名</TableHead>
                  <TableHead className="text-muted-foreground">邮箱</TableHead>
                  <TableHead className="text-muted-foreground">权限</TableHead>
                  <TableHead className="text-muted-foreground">状态</TableHead>
                  <TableHead className="text-muted-foreground">加入日期</TableHead>
                  <TableHead className="text-right text-muted-foreground">操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {admins.map((m) => (
                  <TableRow key={m.id} className="border-border hover:bg-accent/50">
                    <TableCell className="font-medium">{m.name}</TableCell>
                    <TableCell className="text-sm">{m.email}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 text-xs ${ROLE_BADGE[m.role]}`}>
                        {ROLE_LABEL[m.role]}
                      </span>
                    </TableCell>
                    <TableCell>
                      <button
                        onClick={() => updateStatus.mutate({ id: m.id, data: { status: m.status === "active" ? "inactive" : "active" } })}
                        disabled={updateStatus.isPending}
                        className={`px-2 py-1 text-xs cursor-pointer transition-opacity hover:opacity-70 disabled:cursor-not-allowed ${m.status === "active" ? "bg-primary/20 text-primary border border-primary/30" : "bg-muted text-muted-foreground border border-border"}`}
                        title={m.status === "active" ? "点击停用" : "点击启用"}
                      >
                        {m.status === "active" ? "活跃" : "停用"}
                      </button>
                    </TableCell>
                    <TableCell>{format(new Date(m.joinedAt), "yyyy-MM-dd")}</TableCell>
                    <TableCell className="text-right">
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-destructive hover:text-destructive hover:bg-destructive/10 rounded-none"
                        onClick={() => { if (confirm(`确定要移除管理员 ${m.name} 吗？`)) deleteMember.mutate({ id: m.id }); }}
                        disabled={deleteMember.isPending}
                      >
                        移除
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </div>
      )}

      {/* Member section */}
      <div>
        <h2 className="text-sm font-bold mb-3 tracking-widest text-muted-foreground flex items-center gap-2">
          <Users className="w-3.5 h-3.5" />
          会员账户
        </h2>
        <div className="border border-border bg-card overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="text-muted-foreground">姓名</TableHead>
                <TableHead className="text-muted-foreground">邮箱/电话</TableHead>
                <TableHead className="text-muted-foreground">状态</TableHead>
                <TableHead className="text-muted-foreground">加入日期</TableHead>
                <TableHead className="text-right text-muted-foreground">操作</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {regularMembers.map((m) => (
                <TableRow key={m.id} className="border-border hover:bg-accent/50">
                  <TableCell className="font-medium">{m.name}</TableCell>
                  <TableCell>
                    <div className="text-sm">{m.email}</div>
                    <div className="text-xs text-muted-foreground">{m.phone}</div>
                  </TableCell>
                  <TableCell>
                    <button
                      onClick={() => updateStatus.mutate({ id: m.id, data: { status: m.status === "active" ? "inactive" : "active" } })}
                      disabled={updateStatus.isPending}
                      className={`px-2 py-1 text-xs cursor-pointer transition-opacity hover:opacity-70 disabled:cursor-not-allowed ${m.status === "active" ? "bg-primary/20 text-primary border border-primary/30" : "bg-muted text-muted-foreground border border-border"}`}
                      title={m.status === "active" ? "点击停用" : "点击启用"}
                    >
                      {m.status === "active" ? "活跃" : "停用"}
                    </button>
                  </TableCell>
                  <TableCell>{format(new Date(m.joinedAt), "yyyy-MM-dd")}</TableCell>
                  <TableCell className="text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      className="text-destructive hover:text-destructive hover:bg-destructive/10 rounded-none"
                      onClick={() => { if (confirm(`确定要移除会员 ${m.name} 吗？`)) deleteMember.mutate({ id: m.id }); }}
                      disabled={deleteMember.isPending}
                    >
                      移除
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
              {regularMembers.length === 0 && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-muted-foreground py-8">暂无会员</TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Add member dialog */}
      <Dialog open={memberDialogOpen} onOpenChange={setMemberDialogOpen}>
        <DialogContent className="bg-card border-border rounded-none sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle className="tracking-widest flex items-center gap-2">
              <Users className="w-4 h-4" />
              添加新会员
            </DialogTitle>
          </DialogHeader>
          <Form {...memberForm}>
            <form onSubmit={memberForm.handleSubmit(onMemberSubmit)} className="space-y-4 pt-2">
              <MemberFormFields form={memberForm} isPending={createMember.isPending} onClose={() => setMemberDialogOpen(false)} />
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Add admin dialog */}
      <Dialog open={adminDialogOpen} onOpenChange={setAdminDialogOpen}>
        <DialogContent className="bg-card border-border rounded-none sm:max-w-[480px]">
          <DialogHeader>
            <DialogTitle className="tracking-widest flex items-center gap-2">
              <Shield className="w-4 h-4 text-primary" />
              添加管理员
            </DialogTitle>
          </DialogHeader>
          <Form {...adminForm}>
            <form onSubmit={adminForm.handleSubmit(onAdminSubmit)} className="space-y-4 pt-2">
              {/* Permission selector */}
              <FormField
                control={adminForm.control}
                name="role"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>管理权限</FormLabel>
                    <div className="grid grid-cols-2 gap-3 pt-1">
                      <button
                        type="button"
                        onClick={() => field.onChange("course_admin")}
                        className={`p-3 border text-left transition-colors ${
                          field.value === "course_admin"
                            ? "border-primary bg-primary/10"
                            : "border-border bg-background hover:bg-muted/40"
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <div className={`w-3 h-3 rounded-full border-2 flex items-center justify-center ${field.value === "course_admin" ? "border-primary" : "border-muted-foreground"}`}>
                            {field.value === "course_admin" && <div className="w-1.5 h-1.5 rounded-full bg-primary" />}
                          </div>
                          <span className="text-sm font-medium">课程管理员</span>
                        </div>
                        <p className="text-xs text-muted-foreground leading-relaxed">
                          仅可管理课程排班（新增、删除课程）
                        </p>
                      </button>
                      <button
                        type="button"
                        onClick={() => field.onChange("admin")}
                        className={`p-3 border text-left transition-colors ${
                          field.value === "admin"
                            ? "border-primary bg-primary/10"
                            : "border-border bg-background hover:bg-muted/40"
                        }`}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <div className={`w-3 h-3 rounded-full border-2 flex items-center justify-center ${field.value === "admin" ? "border-primary" : "border-muted-foreground"}`}>
                            {field.value === "admin" && <div className="w-1.5 h-1.5 rounded-full bg-primary" />}
                          </div>
                          <span className="text-sm font-medium">超级管理员</span>
                        </div>
                        <p className="text-xs text-muted-foreground leading-relaxed">
                          可管理课程、会员及公告，拥有全部权限
                        </p>
                      </button>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <MemberFormFields form={adminForm} isPending={createMember.isPending} onClose={() => setAdminDialogOpen(false)} />
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
