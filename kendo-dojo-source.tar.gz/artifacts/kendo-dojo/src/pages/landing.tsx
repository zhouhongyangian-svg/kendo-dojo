import { Redirect, Link } from "wouter";
import { useAuth } from "@/contexts/auth-context";
import { Button } from "@/components/ui/button";

export default function Landing() {
  const { member, isLoading } = useAuth();

  if (isLoading) return null;

  if (member) {
    return <Redirect to={member.role === "admin" ? "/admin" : "/dashboard"} />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col">
      <header className="absolute top-0 w-full z-10 p-6 flex justify-between items-center bg-gradient-to-b from-black/80 to-transparent">
        <h1 className="text-2xl font-bold tracking-widest text-primary">长安剑士会</h1>
        <Button asChild variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground font-medium rounded-none tracking-widest">
          <Link href="/sign-in">登 录</Link>
        </Button>
      </header>

      <main className="flex-1 relative flex items-center justify-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="/kendo-hero.png" 
            alt="Kendo Dojo" 
            className="w-full h-full object-cover object-center opacity-60"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        </div>

        <div className="relative z-10 text-center max-w-3xl px-6">
          <h2 className="text-5xl md:text-7xl font-serif font-bold tracking-wider mb-6 drop-shadow-lg text-white">剑道·修心</h2>
          <p className="text-xl md:text-2xl text-muted-foreground font-light mb-12 drop-shadow-md">
            以剑磨心，以心御剑。传承正统剑道精神，打造专注、自律、优雅的修习空间。
          </p>
          <Button asChild size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground rounded-none text-lg px-12 py-6 tracking-widest border border-transparent shadow-[0_0_20px_rgba(220,38,38,0.3)]">
            <Link href="/sign-in">开 始 修 习</Link>
          </Button>
        </div>
      </main>
    </div>
  );
}
