import { Router, Request, Response } from "express";
import { db } from "@workspace/db";
import { announcementsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth, requireAdmin } from "../middlewares/requireAuth";

const router = Router();

router.get("/", requireAuth, async (_req: Request, res: Response) => {
  try {
    const announcements = await db
      .select()
      .from(announcementsTable)
      .orderBy(desc(announcementsTable.isPinned), desc(announcementsTable.createdAt));

    return res.json(announcements.map(a => ({ ...a, createdAt: a.createdAt.toISOString() })));
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", requireAdmin, async (req: Request, res: Response) => {
  try {
    const { title, content, isPinned } = req.body;
    if (!title || !content) {
      return res.status(400).json({ error: "Title and content are required" });
    }

    const [announcement] = await db.insert(announcementsTable).values({
      title,
      content,
      isPinned: isPinned ?? false,
    }).returning();

    return res.status(201).json({ ...announcement, createdAt: announcement.createdAt.toISOString() });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:id", requireAdmin, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const { title, content, isPinned } = req.body;

    const updates: Partial<typeof announcementsTable.$inferInsert> = {};
    if (title !== undefined) updates.title = title;
    if (content !== undefined) updates.content = content;
    if (isPinned !== undefined) updates.isPinned = isPinned;

    const [announcement] = await db
      .update(announcementsTable)
      .set(updates)
      .where(eq(announcementsTable.id, id))
      .returning();

    if (!announcement) return res.status(404).json({ error: "Announcement not found" });
    return res.json({ ...announcement, createdAt: announcement.createdAt.toISOString() });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id", requireAdmin, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const [deleted] = await db.delete(announcementsTable).where(eq(announcementsTable.id, id)).returning();
    if (!deleted) return res.status(404).json({ error: "Announcement not found" });
    return res.json({ success: true });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
