import { Router, Request, Response } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { membersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { requireAdmin } from "../middlewares/requireAuth";

const router = Router();

router.get("/", requireAdmin, async (_req: Request, res: Response) => {
  try {
    const members = await db.select({
      id: membersTable.id,
      name: membersTable.name,
      email: membersTable.email,
      phone: membersTable.phone,
      role: membersTable.role,
      status: membersTable.status,
      joinedAt: membersTable.joinedAt,
    }).from(membersTable).orderBy(membersTable.joinedAt);

    return res.json(members.map(m => ({ ...m, joinedAt: m.joinedAt.toISOString() })));
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/", requireAdmin, async (req: Request, res: Response) => {
  try {
    const { name, email, password, phone, role } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: "Name, email and password are required" });
    }

    const existing = await db.select().from(membersTable).where(eq(membersTable.email, email)).limit(1);
    if (existing.length > 0) {
      return res.status(400).json({ error: "Email already exists" });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const [member] = await db.insert(membersTable).values({
      name,
      email,
      passwordHash,
      phone: phone || null,
      role: role || "member",
      status: "active",
    }).returning();

    return res.status(201).json({
      id: member.id,
      name: member.name,
      email: member.email,
      phone: member.phone,
      role: member.role,
      status: member.status,
      joinedAt: member.joinedAt.toISOString(),
    });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/:id", requireAdmin, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const [member] = await db.select({
      id: membersTable.id,
      name: membersTable.name,
      email: membersTable.email,
      phone: membersTable.phone,
      role: membersTable.role,
      status: membersTable.status,
      joinedAt: membersTable.joinedAt,
    }).from(membersTable).where(eq(membersTable.id, id)).limit(1);

    if (!member) return res.status(404).json({ error: "Member not found" });

    return res.json({ ...member, joinedAt: member.joinedAt.toISOString() });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/:id", requireAdmin, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const { status } = req.body;

    if (!status || !["active", "inactive"].includes(status)) {
      return res.status(400).json({ error: "status must be 'active' or 'inactive'" });
    }

    const [updated] = await db
      .update(membersTable)
      .set({ status })
      .where(eq(membersTable.id, id))
      .returning();

    if (!updated) return res.status(404).json({ error: "Member not found" });

    return res.json({
      id: updated.id,
      name: updated.name,
      email: updated.email,
      phone: updated.phone,
      role: updated.role,
      status: updated.status,
      joinedAt: updated.joinedAt.toISOString(),
    });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/:id", requireAdmin, async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id);
    const [deleted] = await db.delete(membersTable).where(eq(membersTable.id, id)).returning();
    if (!deleted) return res.status(404).json({ error: "Member not found" });
    return res.json({ success: true });
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
